#ifndef _AUDIO_H_
#define _AUDIO_H_

#include "export.h"

#ifdef __cplusplus
extern "C" {
#endif	

EXPORT_SYM void beep(void);

#ifdef __cplusplus
}
#endif

#endif

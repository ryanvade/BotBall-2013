#include "nyi.h"

#include <iostream>

void nyi(const char *name)
{
	std::cout << "Warning: " << name << " not yet implemented." << std::endl;
}
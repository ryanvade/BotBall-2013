#ifndef _BITS_P_HPP_
#define _BITS_P_HPP_

namespace Private
{
	class Bits
	{
	public:
		static unsigned char leadingZeros(const unsigned i);
	};
}


#endif

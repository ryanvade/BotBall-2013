#include "kovan/audio.h"

#include <cstdio>

void beep(void)
{
	printf("\a");
}
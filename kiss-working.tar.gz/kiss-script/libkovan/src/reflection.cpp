#include "kovan/reflection.hpp"
/* 
class Node
{
public:
	
private:
	
};

class CommandLexer
{
public:
	CommandLexer();
	
	
	
	void setStartParameterBlockDelimeters(const char& c);
	const char& startParameterBlockDelimeters() const;
	
	void setEndParameterBlockDelimeters(const char& c);
	const char& endParameterBlockDelimeters() const;
	
private:
	char m_startParameterBlock;
	char m_endParameterBlock;
};

ReturnValue ReflectionEngine::interpret(const std::string& command)
{
	
}

RelfectionEngine *ReflectionEngine::instance()
{
	static ReflectionEngine s_engine;
	return &s_engine;
}

ReflectionEngine::ReflectionEngine()
{
	
}

ReflectionEngine::ReflectionEngine(const ReflectionEngine&)
{
	// NOT IMPLEMENTED
}

ReflectionEngine& ReflectionEngine::operator=(const ReflectionEngine&)
{
	return *this; // NOT IMPLEMENTED
} */
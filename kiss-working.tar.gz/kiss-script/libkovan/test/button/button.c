#include <kovan/kovan.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
	while(!a_button());
	printf("%d\n", a_button());
}
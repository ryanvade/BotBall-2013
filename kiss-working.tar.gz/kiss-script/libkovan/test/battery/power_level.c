#include <kovan/kovan.h>

int main(int argc, char* argv[])
{
	printf("power level = %f\n", power_level());
	return 0;
}
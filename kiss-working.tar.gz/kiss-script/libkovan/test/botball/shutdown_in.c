#include <kovan/kovan.h>

int main(int argc, char *argv[])
{
	shut_down_in(10.0);
	for(;;);
	return 0;
}
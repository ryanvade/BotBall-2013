#include "target_responder.hpp"

Kiss::Target::Responder::~Responder()
{
}
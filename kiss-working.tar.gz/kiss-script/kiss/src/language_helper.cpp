#include "language_helper.hpp"

Kiss::LanguageHelper::~LanguageHelper()
{
}
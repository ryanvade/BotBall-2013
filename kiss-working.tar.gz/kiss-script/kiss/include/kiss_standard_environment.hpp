#ifndef _KISS_STANDARD_ENVIRONMENT_HPP_
#define _KISS_STANDARD_ENVIRONMENT_HPP_

namespace Kiss
{
	class StandardEnvironment
	{
	public:
		static void createStandardEnvironment();
	};
}

#endif
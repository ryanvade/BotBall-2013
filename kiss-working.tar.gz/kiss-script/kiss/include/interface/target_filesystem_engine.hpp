#ifndef _TARGET_FILESYSTEM_MODEL_HPP_
#define _TARGET_FILESYSTEM_MODEL_HPP_

#include <QAbstractFileEngine>

namespace Kiss
{
	namespace Target
	{
		class FilesystemEngine : public QAbstractFileEngine
		{
			
		};
	}
}

#endif

// Created on Mon March 25 2013

int main()
{
	printf("Hello, World!\n");
	return 0;
}

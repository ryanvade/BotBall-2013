#ifndef _KEYS_HPP_
#define _KEYS_HPP_

#define AVAILABLE_KEY "available?"
#define COMPILE_KEY "compile"
#define DOWNLOAD_KEY "download"
#define RUN_KEY "run"
#define LIST_KEY "list"
#define DELETE_KEY "delete"
#define INTERACTION_KEY "interaction"
#define LOCKED_KEY "locked"
#define AUTHENTICATE_KEY "authenticate"

#endif

#ifndef _SOCKET_UTILS_HPP_
#define _SOCKET_UTILS_HPP_

bool setBlocking(int fd, bool blocking);
bool closeSocket(int fd);


#endif

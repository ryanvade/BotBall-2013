#include "kovanserial/transmitter.hpp"

Transmitter::~Transmitter()
{
	
}
#ifndef _PLATFORM_DEFINES_HPP_
#define _PLATFORM_DEFINES_HPP_

#ifdef WIN32
#define KOVAN_SERIAL_PATH_SEP ("\\")
#else
#define KOVAN_SERIAL_PATH_SEP ("/")
#endif

#endif

#ifndef _GENERAL_HPP_
#define _GENERAL_HPP_

long msystime();
void yield();

#endif

This is where the i2c_wrapper static library is placed. Use this directory as LDLIBS when compiling against i2c_wrapper

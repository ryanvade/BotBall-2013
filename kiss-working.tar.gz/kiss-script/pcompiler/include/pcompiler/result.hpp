#ifndef _RESULT_HPP_
#define _RESULT_HPP_

namespace Compiler
{
}

#endif

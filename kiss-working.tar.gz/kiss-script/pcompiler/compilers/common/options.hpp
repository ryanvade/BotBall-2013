#ifndef __OPTIONS_HPP__
#define __OPTIONS_HPP__

#define TEMPORARY_DIR "TEMPORARY_DIR"
#define OUTPUT_DIR "OUTPUT_DIR"

#endif

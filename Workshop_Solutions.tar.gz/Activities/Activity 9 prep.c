int main() { // Activity 9 prep
  int x,y;
  camera_open(LOW_RES);
  printf("Looking for blob\n\nPress side button to quit\n");
  while(!side_button()){ //run until side is pressed
    camera_update(); // process the most recent image
    if(get_object_count(1) > 0){ // any blobs of the trained color?
      x = get_object_center(1,0).x; y = get_object_center(1,0).y; 
      // store x,y of biggest blob
      printf("Color Blob at (%i,%i)\n",x,y); msleep(200); 
    }
    else{ printf("No Blob in Frame\n"); }
  }
  printf("Program is done.\n");
  return 0;
}

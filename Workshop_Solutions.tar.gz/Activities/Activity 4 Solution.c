/******* If A turn left, if C turn right (mirror behavior) *******/
int turn_left(double seconds);  // prototype for turn_left
void turn_right(double seconds); // prototype for turn_right
int main() {
  // 1. Rename buttons
  set_a_button_text("Left"); set_c_button_text("Right"); 
  printf("Side button to stop\n"); // announce
  create_connect(); // 2. Connect to the Create
  // 3a. Loop until the side button is pressed.
  while (side_button() == 0) {
    // 3b. If the 'A' button is pressed, then turn left
    if (a_button() == 1) { 
	  printf("turned left %i degrees\n", turn_left(1.0)); }
    // 3c. Else if the 'C' button is pressed, then turn right
    else if (c_button() == 1) { turn_right(1.0); }
  }
  create_disconnect(); // 4. Disconnect from the Create
  printf("All Done\n"); // Tell user program has finished
  return 0;
}
/*Function definitions go below*/
int turn_left(double seconds) {
  int initial_angle = get_create_total_angle(0); 
  //  Move left wheel backward and right wheel forward
  create_drive_direct(-300, 300);
  //  Delay for time equal to the parameter value
  msleep(seconds*1000);
  //  Stop the Create
  create_stop();
  //  return the angle turned left
  return(get_create_total_angle(0) - initial_angle);
}
void turn_right(double seconds) {
  //  Move the Create left wheel forward
  //    and the right wheel backward
  create_drive_direct(300, -300);
  //  Delay for time equal to the parameter value
  msleep(seconds*1000);
  //  Stop the Create
  create_stop();
}

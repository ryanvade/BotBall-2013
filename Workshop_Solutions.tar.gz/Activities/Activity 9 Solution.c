#define ARMPORT 0
int main()
  {
    int offset, x, y;
    enable_servos();
    camera_open(LOW_RES);
    camera_update(); // get most recent camera image and process it
    while(side_button() == 0) {
      x = get_object_center(0,0).x; // get image x data
      y = get_object_center(0,0).y;//    and y data
      if(get_object_count(0) > 0) {  // there is a blob
        display_printf(0,4,"Blob is at (%i,%i)\n",x,y);
        offset=5*(y-60);  // amount to deviate servo from center
        set_servo_position(ARMPORT,1024+offset);
      }
      else {
        display_printf(0,4,"No colored object in sight\n");
      }
      msleep(200);     // don't rush print statement update
      camera_update();  // get new image data before repeating
    }
    disable_servos();
    printf("All done\n");
    return 0;
}



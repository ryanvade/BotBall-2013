// Assume default configuration is used and channel 1 is for QR
// If a QR code is found, it is translated
int main() {
	int i;
	camera_open(LOW_RES); // camera at low resolution is good enough
	while(1) {
      for (i=0; i<10; i++) camera_update(); // flush frame buffer
      printf("Looking for QR code\n");      // wait until QR code found
      while (get_object_count(1) == 0) camera_update(); 
      printf("Have found %d\n", get_object_count(1));
      for(i=0; i<get_object_data_length(1,0); i++)
        // print QR code letter by letter until end of data
        printf("%c",get_object_data(1,0)[i]); 
      printf("\nA button to do another; C button to quit\n");
      while(!(a_button()||c_button())); // wait for user response
      if(c_button()) break;             // quit if C pressed
	}
	printf("done\n");
	return 0;
}



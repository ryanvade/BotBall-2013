/*************************************************************
*********  Activity 1               *************************************************************/
int main()
{
	// 1. Display "Hello World!" to the screen
	printf("Hello World!\n");
	
	// 2. Delay for 2 seconds
	msleep(2000);    //2000ms = 2s
	
	// 3. Display your name to the screen
	printf("My name is Botguy.\n"); 

	return 0;        
}

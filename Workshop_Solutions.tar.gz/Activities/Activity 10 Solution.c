// *********  Bang Bang Control
int main()
{
  // Step 1: Set analog port 0 to floating analog
  set_analog_pullup(0,0);
  printf("Back up if obstacle too close\n   otherwise go forward\n");
  printf("Press A button to start\n\n");
  while (a_button() == 0);
  printf("Press side button to stop\n"); 
  // Step 2: Loop until side button is pressed 
  while (side_button() == 0) {
    // Step 2a: If the floating analog rangefinder on port 0 reads
    //    greater than 600, back up.
    if (analog10(0) > 600) { motor(0,-50); motor(3,-50); }	  
    // Step 2b: Otherwise, drive ahead
    else { motor(0,50); motor(3,50); }
  }
  // Step 3: Stop
  ao();
  printf("done\n");
  return 0;
}



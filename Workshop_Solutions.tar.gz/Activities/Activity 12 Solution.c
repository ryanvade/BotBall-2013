//Using the Camera to track and go to a specific QR code
//Assumes that channel 0 of default config is QR code 
int main(){
	int x, y, blob;	
	int leftmtr=0, rghtmtr=3; 
	int high=30, low=0;      
	char q = ' ';	
	camera_open(LOW_RES); //start up camera
	set_a_button_text("Track P"); 
	msleep(100);
	set_b_button_text("Stop");
	msleep(100);
	set_c_button_text("Track T"); 
	printf("choose which QR code to track\n");
	while(q == ' ') {
		if(a_button() == 1) q = 'P';
		if(c_button() == 1) q = 'T';
	}
	printf("Looking for QR code %c\n",q);
	msleep(300);
	while(digital(15)==0) {		
		ao();
		camera_update();// get a new image	
		printf("# of items %i\n", get_object_count(0));
		if(get_object_count(0) > 0) {// is there a QR code?				
			printf("Found QR Code\n");
			
			int found_blob = 0;
			for(blob=0; blob < get_object_count(0); blob++)//check the largest 10 QR codes for data			
			{
				if(get_object_data_length(0, blob) == 0) continue;
				
				printf("QR code begins with %c\n", get_object_data(0,blob)[0]);
				//compare data to what we are searching for
				if(get_object_data(0,blob)[0] == q) {
					found_blob = 1;
					break;
				}
			}
			
			// if valid QR code was found, close in
			if(found_blob) { 
				printf("Tracking...\n");
				while(digital(15)==0) { // stop when button is pressed
					x = get_object_center(0,blob).x;
					printf("X=%i\n", x);
					if (x < 60) { // continue until qr code on right
						motor(leftmtr,low); motor(rghtmtr,high);   // arc left
						if (digital(15)!=0) break; // or button pressed
					}
					if (x >= 60){     // continue until code on left
						motor(leftmtr,high); motor(rghtmtr,low);  // arc right
						if (digital(15)!=0) break; // or button pressed
					}
					if(x==-1){break;}//lost blob
					camera_update();// get a new image
				}
				
			}
		}
		 							
		printf("code not found...searching...\n");
		motor(leftmtr,20);
		motor(rghtmtr,-20);
		msleep(50);
		ao();
		// msleep(400);
		
	}
	printf("Done\n");
	return(0);
}


/* Line following with a single sensor: arc left when the 
    reflectance sensor detects dark and otherwise arc right
 Use the Sensor Ports screen to find the high & low
    reflectance sensor values for the robot on the surface
 Set the threshold halfway between                        */
int main()
{
  int rport=7, leftmtr=0, rghtmtr=3;  // identify port and motors
  int threshold=512;         // set threshold for light conditions
  int high=60,low=40;      // set wheel powers for arc radius
  printf("Line following: position robot on tape\n");
  printf("Press B button when ready\n\nPress side button to stop\n");
  while(b_button()==0) {}    // wait for button press
  while(side_button()==0){            // stop if button is pressed
     while (analog10(rport) > threshold) { // continue until not dark
       motor(leftmtr,low); motor(rghtmtr,high);   // arc left
       if (side_button()!=0) break; }     // or button pressed
     while (analog10(rport) <= threshold){     // continue until dark
        motor(leftmtr,high); motor(rghtmtr,low);  // arc right
       if (side_button()!=0) break; }     // or button pressed
  }
  ao();  // stop because button pressed
  printf("done\n");
  return 0;
}

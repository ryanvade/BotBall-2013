//  Using proportional control to operate an arm
#define UPOS 200   // servo positions for arm up
#define DPOS 1200  // servo positions for arm down
#define ARMPORT 0  // servo port for arm
#include <math.h>
void raise_arm();  // prototype for arm function
void lower_arm();  // prototype for arm function
int main() {
  set_servo_position(ARMPORT, DPOS); // initialize arm down
  enable_servos();                   //   and start servos
  printf("Lower and raise arm until side button pressed\n");
  printf("Press A button to start\n\n");
  while(a_button() == 0);
  while(side_button() == 0) {       // repeat until user presses button
    msleep(1000); raise_arm();      // leave down briefly, then raise it
    printf("Arm is up\n");
    msleep(1000); lower_arm();      // leave up briefly, then lower it
    printf("Arm is down\n");
  }
  disable_servos(); // shut down servos
  printf("DONE!");
  return 0;
}
void raise_arm() { 
	int amt, srvpos = get_servo_position(ARMPORT); 
	int midpt = UPOS +(DPOS-UPOS)/2; 
	while (srvpos > (UPOS+5) ) {  // quit if close enough
		if (srvpos < midpt) amt = 5 + sqrt(srvpos-UPOS); 
		else amt = 5+sqrt(DPOS-srvpos);              
		srvpos = srvpos - amt;    // move closer to UPOS
		set_servo_position(ARMPORT,srvpos); // move arm
		msleep(100);  // give time to move
	}
   set_servo_position(ARMPORT, UPOS); // finalize at UPOS
}
void lower_arm() { 
	int amt, srvpos = get_servo_position(ARMPORT); 
	int midpt = UPOS +(DPOS-UPOS)/2; // point of fastest travel
	while (srvpos < (DPOS-5)) {   // quit if close enough 
		if(srvpos < midpt) {amt = 5 + sqrt(srvpos-UPOS); } // move amount
		else { amt = 5 + sqrt(DPOS-srvpos); }              // (at least 5)
		srvpos = srvpos + amt;   // move srvpos closer to DPOS
		set_servo_position(ARMPORT,srvpos); // move arm
		msleep(100);              // give time to move
	}
   set_servo_position(ARMPORT, DPOS); // finalize at DPOS
}	





// *********  Proportional Control; uncomment/comment for pid vs pwm
int main() {
  int mpv; // motor power or velocity
  double pc; int adj, distval; // adjusters
  pc = 1.0; adj = 3; distval = 100; // for pwm
  //pc = 3; adj = 1; distval = 300; // for pid
  // Step 1: Set analog port 0 to floating analog
  set_analog_pullup(0,0);  // ET readings between 0 and 600
  printf("Back up if obstacle too close\n   otherwise go forward\n");
  printf("Press A button to start\n\n");
  while (a_button() == 0);
  printf("Press side button to stop\n");
  // Step 2: Loop until side button is pressed
  while (side_button() == 0) {
    // Step 2a: move the motors proportional to the distance to the obstacle
    mpv = pc * (distval - analog10(0)/adj);
    motor(0,mpv); motor(2,mpv); // for pwm
    //mav(0,mpv); mav(2,mpv);    // for pid
    display_printf(0,0,"%d   ",analog10(0)); msleep(100);  // show ET values
  }
  // Step 3: Stop
  ao();
  printf("done\n");
  return 0;
}


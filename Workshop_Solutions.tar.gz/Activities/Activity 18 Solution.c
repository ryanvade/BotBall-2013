/* Line following with a single sensor: arc left when the reflectance sensor detects dark and otherwise arc right. Use the Sensor Ports screen to find the high & low reflectance values, threshold halfway between */
int rport=6, leftmtr=2, rghtmtr=0;  // port & motors
void monitor() { // monitor program to run in a thread
  while(1) {
    display_printf(1,2,"Port %d reading: %d   ",rport,analog10(rport));
    msleep(100);
  }
}
int main()
  {
    thread t;                   // thread variable for monitor program
    int threshold=500;
    int high=50,low=-5;         // wheel power for arc radius
    set_a_button_text("START");
    display_clear();
    t = thread_create(monitor); // create a thread for monitor function
    thread_start(t);            // start monitoring the reflectance sensor
    display_printf(0,0,"Line following: position robot on tape");
    while(a_button()==0);       // wait for START pressed
    set_b_button_text("STOP");
    while(b_button()==0){       // wait for STOP pressed
      while (analog10(rport) > threshold) { // arc left till light
        motor(leftmtr,low); motor(rghtmtr,high);
        if (b_button()!=0) break;
      }
      while (analog10(rport) <= threshold){ // arc right till dark
        motor(leftmtr,high); motor(rghtmtr,low);
        if (b_button()!=0) break;
      }
    }
    ao();                   // motor off
    thread_destroy(t);      // clean up
    display_printf(0,9,"done\n");
    return 0;
}

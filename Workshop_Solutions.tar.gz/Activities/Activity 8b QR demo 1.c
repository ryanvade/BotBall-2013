// Prints the center coordinate of P QR codes otherwise prints first letter
int main(){ // Assumes that channel 0 of default config is QR code	
  int x,y;	
  char q;	
  camera_open(LOW_RES); //start up camera
  while(a_button()==0){		
    camera_update();// get a new image	
    if(get_object_count(0)>0){// is there a QR code?
      if(get_object_data(0,0)[0]=='P'){// Is it a P
        x=get_object_center(0,0).x;	
        y=get_object_center(0,0).y;
        printf("P found at %i,%i\n",x,y);
      }			
      else{ // QR code is not P	
        q=get_object_data(0,0)[0];
        printf("QR code begins with %c\n",q);	
      }	
    }
  }
  printf("Done\n");
  return(0);
}


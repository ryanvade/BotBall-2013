// Set up a camera configuration that is calibrated so that it recognizes
// a red colored object for color channel 0 before running the program 
// and make sure that configuration is the default
int main() { 	// Start up the camera and specify the resolution
	camera_open(LOW_RES);	
	int x, y, color=0;  // set up for color channel 0 (red)
	printf("Looking for red\nPress A when ready\n\n");
	printf("Press B button to quit\n");
 	while (a_button() == 0); // wait for A button
	while (b_button() == 0){ // run till B button is pressed
		camera_update(); // process the most recent image
		if (get_object_count(color) > 0){
			//get x, y for the biggest blob the channel sees			x = get_object_center(color,0).x;
			y = get_object_center(color,0).y;
 			printf("Biggest blob at (%i,%i)\n",x,y);
 		}
		else{ 
			printf("No color match in Frame\n"); 
		}
		msleep(200);  // give user time to read
  	}  
	printf("Program is done.\n");  
	return 0;
}

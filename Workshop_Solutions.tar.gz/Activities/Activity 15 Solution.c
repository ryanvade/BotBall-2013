// Using the accelerometer to detect a hit when moving the Create module
int main() {
  int fwd_bk = -1;
  int threshold = 100;
  create_connect(); 
  printf("Forward and back reversing direction on impact\n");
  printf("Press A button when ready\n\nPress side button to quit\n");
  while (a_button() == 0) {} 
  while (side_button() == 0) {
    // monitor for a hit while going backward
    create_drive_straight(-250); // start going backwards
    msleep(500);                  // give time to reach constant velocity
    while (fwd_bk == -1) {
      printf("Moving backwards\n");
      if (accel_y() > threshold) { fwd_bk = 1; } // hit, reverse direction
      if (side_button() == 1) { break; }
    }
    // monitor for a hit while going forward
    create_drive_straight(250); // start going forwards
    msleep(500);                 // give time to reach constant velocity
    while (fwd_bk == 1) {
      printf("Moving forward\n");
      if (accel_y() < -threshold) { fwd_bk = -1; }
                                // hit detected, reverse direction
      if (side_button() == 1) { break; }	
    }
  }
  create_disconnect();
  printf("done\n");
  return 0;
}






//Define the base robot speed and the forward offset to keep the bumper pressed
#define SPEED 50
#define FOR 15
double timeTurn2Bumps(int dir);// function measures how long both bumpers are pressed
void turnHalfTime2Bumps(int dir, double time);//turn in direction dir for half of time
int main() 
  {
    int dir=1;//dir = 1 means CCW and -1 means CW
    create_connect();  // connect to Create
    printf("press A to start towards a wall\n");
    while(a_button()==0);// wait for the A button to be pressed
    while(!get_create_lbump() && !get_create_rbump()){
      create_drive_straight(2*SPEED);// drive forward till either bumper is pressed
    }//if the left bumper and not the right is pressed, reverse rotation direction
    if(get_create_lbump() && !get_create_rbump()) dir=-dir;
    else {//if both bumpers are pressed, spin until only the right is pressed
      if(get_create_lbump() && get_create_rbump()){
        while(get_create_rbump()){
          create_spin_CCW(50);
        }
        msleep(100);//and then spin 0.1 sec longer
      }
    }//find how long, during rotation both bumpers are pressed
    turnHalfTime2Bumps(-dir,timeTurn2Bumps(dir)); //then turn back half that time
    printf("Create is orthogonal to wall. Done.\n");
}

double timeTurn2Bumps(int dir){// dir determines which direction to rotate
  double startTime, turnTime;
  create_drive_direct(-dir*SPEED+FOR,dir*SPEED+FOR);//spin while pressing forward 
  while(!(get_create_lbump() && get_create_rbump()));//wait till both bumpers are hit 
  startTime=seconds();//seconds uses system clock
  while(get_create_lbump() && get_create_rbump()); //wait till both bumpers are hit  
  turnTime=seconds()-startTime;//turnTime holds the amount of time both bumpers were pressed
  msleep(100);//turn a little further
  create_stop();//stop
  return (turnTime);//send back how long both bumpers were pressed
}

void turnHalfTime2Bumps(int dir, double time){
  double startTime;
  create_drive_direct(-dir*SPEED+FOR,dir*SPEED+FOR);//spin while pressing forward
  while(!(get_create_lbump() && get_create_rbump())); //wait till both bumpers are hit   
  startTime=seconds();//startTime occurs when both bumpers are pressed
  while(seconds()-startTime < time/2.0);//keep turning for half of time
  create_stop();//stop and Create should be orthogonal against wall
}







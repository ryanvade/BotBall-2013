// Using a servo motor to operate an arm using bang-bang control 
#define DOWN 0     // arm is raised
#define UP 1       // arm is lowered
#define UPOS 200   // servo position arm raised
#define DPOS 1200  // servo position arm lowered
#define ARMPORT 0  // servo port for arm               
void arm(int up_down);  // prototype for arm function
int main() {
  arm(UP);                     // initialize arm position as up
  enable_servos();             // start servos with arm up
  printf("Lower and raise arm until side button pressed\n");
  printf("Press A button to start\n\n");
  while(a_button() == 0);
  while(side_button() == 0) { // repeat until user presses side button
    msleep(2000); arm(DOWN);  // leave up for 2 seconds, then lower it
    msleep(2000); arm(UP);    // leave down for 2 seconds, then raise it
  }
  disable_servos();           // shut down servos
  printf("Done!\n");
  return 0;
}
void arm(int up_down) {
  if (up_down != 0) set_servo_position(ARMPORT, UPOS);
  else set_servo_position(ARMPORT, DPOS);
}



